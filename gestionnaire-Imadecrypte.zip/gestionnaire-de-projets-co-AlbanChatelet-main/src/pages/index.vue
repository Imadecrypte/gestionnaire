<script setup lang="ts">


</script>

<template>
  <header>
    
    <div class="wrapper">
      <h1 class="text-2xl bg-slate-400">Page d'accueil</h1>
      
    </div>
    </header>
</template>