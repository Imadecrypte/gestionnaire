<script setup lang="ts">


</script>

<template>
  <header>
    
    <div class="wrapper">
      <h1 class="text-6xl bg-slate-400">A propos</h1>
      
    </div>
    </header>
</template>